# SoilMoistureChanger

Readme coming later.

# Usage
Change the value of "MoistureDistance" in the config, which is probably in BepInEx\plugins\SoilMoistureChanger\configs\SoilMoisture.json

If the config is not showing, try to launch the game and start up a save, that should create it.

# Change log

## v0.0.1 - 5.10.2022
- Initial release